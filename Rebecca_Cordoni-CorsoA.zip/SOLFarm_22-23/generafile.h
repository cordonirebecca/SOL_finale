//
// Created by rebecca on 15/02/23.
//

#ifndef SOL_GENERAFILE_H
#define SOL_GENERAFILE_H

#endif //SOL_GENERAFILE_H
