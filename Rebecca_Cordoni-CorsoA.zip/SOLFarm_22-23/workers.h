//
// Created by rebecca on 23/12/22.
//

#ifndef SOL_WORKERS_H
#define SOL_WORKERS_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include "list.h"

long sommatoria(char *nome_del_file);


#endif //SOL_WORKERS_H